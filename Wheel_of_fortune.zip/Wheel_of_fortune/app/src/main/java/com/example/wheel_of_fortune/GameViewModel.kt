package com.example.wheel_of_fortune

import androidx.lifecycle.ViewModel

class GameViewModel: ViewModel() {
    private var wordbank = Wordbank()
    private var player = Player(0, 5)
    public val playerLife = player.getLife()
    private var wheel = Wheel()
    private var chosen_word = wordbank.getRandomWord()
    private var recentSpin = 0


    fun changePlayerlife(value: Int){
        player.changeLives(value)
    }

    fun changePlayerPoints(value: Int){
        player.changePoints(value)
    }
    fun playerHasLives(): Boolean {
        return player.lives > 0
    }

    fun setPlayerPoints(value: Int){
        player.setPoints(value)
    }

    fun getRecentSpin(): Int {
        return recentSpin
    }


    fun spinWheel(): Int {
        val value =  wheel.getRandomValue()
        recentSpin = value
        return value
    }

    fun getChosenGenre(): String {
        return chosen_word.getWordGenre()
    }

    fun getPlayerLives(): Int {
        return player.getLife()
    }

    fun getPlayerPoints(): Int{
        return player.getPoints()
    }

    fun getChosenWordString(): String {
        return chosen_word.getWordString()
    }
}