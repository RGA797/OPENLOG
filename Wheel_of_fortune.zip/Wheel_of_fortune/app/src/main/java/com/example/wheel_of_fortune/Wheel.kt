package com.example.wheel_of_fortune

import java.util.*

class Wheel {
    //wheel of fortune values in an array. positive numbers are points, -1 means gain a life,-2 means lose a life, -3 means bankrupt (lose all points).
    var wheel = intArrayOf(-2, 800, 1000, 500, 100, 800, 1000, 500, 600, 800, -1, 600, 500, 100, 1500, -3, 800, 500, 600, 500, -1, -2)

    fun getRandomValue(): Int {
            val wheel_length = wheel.size
            val random_Number = Random().nextInt(wheel_length)
            return wheel[random_Number]
        }
}