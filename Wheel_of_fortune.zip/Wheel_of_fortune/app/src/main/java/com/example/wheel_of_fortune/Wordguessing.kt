package com.example.wheel_of_fortune

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.KeyEvent
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.EditorInfo.IME_NULL
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import com.example.wheel_of_fortune.databinding.FragmentWordguessingBinding


class Wordguessing : Fragment(R.layout.fragment_wordguessing) {

    private val gameViewModel: GameViewModel by viewModels()
    private var _binding:FragmentWordguessingBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View{

        _binding = FragmentWordguessingBinding.inflate(inflater, container, false)

        val view = inflater.inflate(R.layout.fragment_gameover, container, false)

        binding.genreView.text = gameViewModel.getChosenGenre()
        binding.pointsView.text = gameViewModel.getPlayerPoints().toString()
        binding.recentSpinView.text = ""
        binding.lifeView.text = gameViewModel.getPlayerLives().toString()
        binding.editText.visibility = INVISIBLE
        binding.enterButton.visibility = INVISIBLE

        binding.spinButton.setOnClickListener{
            val wheelValue = gameViewModel.spinWheel()

            if (wheelValue > 0) {
                binding.recentSpinView.text = wheelValue.toString()
                binding.spinButton.visibility = INVISIBLE
                binding.editText.visibility = VISIBLE
                binding.enterButton.visibility = VISIBLE
            }
            if (wheelValue == -1){
                binding.recentSpinView.text="You just gained a life!"
                gameViewModel.changePlayerlife(1)
                binding.lifeView.text = gameViewModel.getPlayerLives().toString()
            }
            if (wheelValue == -2){
                binding.recentSpinView.text="You just lost a life!"
                gameViewModel.changePlayerlife(-1)
                binding.lifeView.text = gameViewModel.getPlayerLives().toString()
                if (!gameViewModel.playerHasLives()){
                    Navigation.findNavController(binding.root).navigate(R.id.navigateToGameover)
                }
            }
            if (wheelValue == -3){
                binding.recentSpinView.text="You just went bankrupt"
                gameViewModel.setPlayerPoints(0)
                binding.pointsView.text = gameViewModel.getPlayerPoints().toString()
            }
        }

        binding.enterButton.setOnClickListener{
            val wheelValue = gameViewModel.getRecentSpin()
            val guess = binding.editText.text

            //guess(wheelValue, guess)

            gameViewModel.changePlayerPoints(100)






            binding.pointsView.text = gameViewModel.getPlayerPoints().toString()
            hideKeyboard()

            binding.spinButton.visibility = VISIBLE
            binding.editText.visibility = INVISIBLE
            binding.enterButton.visibility = INVISIBLE

        }

        binding.quitButton.setOnClickListener{
            Navigation.findNavController(binding.root).navigate(R.id.navigateToMenu)
        }

        return binding.root
    }


    //code for hiding keyboard gotten from stackoverflow https://stackoverflow.com/questions/41790357/close-hide-the-android-soft-keyboard-with-kotlin
    fun Context.hideKeyboard(view: View) {
        val inputMethodManager = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun Fragment.hideKeyboard() {
        view?.let { activity?.hideKeyboard(it) }
    }



    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }


}

