package com.example.wheel_of_fortune

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.Navigation


class Victory : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_victory, container, false)


        val playAgainButton = view.findViewById<Button>(R.id.playAgainButton)
        playAgainButton.setOnClickListener{
            Navigation.findNavController(view).navigate(R.id.navigateToWordguessing)
        }

        val quitButton = view.findViewById<Button>(R.id.quitButton)
       quitButton.setOnClickListener{
            Navigation.findNavController(view).navigate(R.id.navigateToMenu)
        }

        return view
    }

}