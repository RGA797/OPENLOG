package com.example.wheel_of_fortune

class Word(val genre: String, val word_string: String){

    fun getWordGenre(): String {
        return genre
    }
    fun getWordString(): String {
        return word_string
    }
}